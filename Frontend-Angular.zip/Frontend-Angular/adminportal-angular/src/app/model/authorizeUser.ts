export class AuthorizeUser{
    fname:string;
    lname: string;
    phone: number;
    address: string;
    pan: string;
    email: string;
    username: string;
}
