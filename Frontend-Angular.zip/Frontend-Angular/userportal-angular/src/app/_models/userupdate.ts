export class UserUpdate {
    userName:string;
    prevpassword:string;
    password: string;
    phone: number;
    address:string;
    email: string;
}