package testing.adminportaltest;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.webdriver.WebDriverBrowser;

public class Admin {
	public String baseUrl = "http://localhost:4201";
	   String driverPath = "D:\\95\\chromedriver.exe";
	    public WebDriver driver ; 
	     
  @BeforeTest
  public void launchBrowser() {
	  System.out.println("Chrome Browser"); 
      System.setProperty("webdriver.chrome.driver", driverPath);
      driver = new ChromeDriver();
      driver.get(baseUrl);
      driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
  }
  @Test(priority=0) public void login_Pass() throws InterruptedException {
	  driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	  driver.findElement(By.name("inputUserName")).sendKeys("admin");
	  driver.findElement(By.name("password")).sendKeys("admin1234");
	  driver.findElement(By.xpath("/html/body/app-root/app-login/body/div/form/button")).click();
	  Thread.sleep(2500);
	  String actualUrl="http://localhost:4200/user-account";
	  String expectedUrl= driver.getCurrentUrl();
	  Thread.sleep(2000);
	  if(actualUrl.equalsIgnoreCase(expectedUrl)) {
	  System.out.println("Login Successful"); }
	  driver.manage().window().maximize();
	  
  }
  @Test(priority=1) public void useraccount_login_enabling() throws InterruptedException{
	  
	  //User Account Hyperlink
	  driver.findElement(By.xpath("//*[@id=\"navbarsExample02\"]/ul/li[1]/a")).click();
	  Thread.sleep(2000);
	  //Enable Button
	  driver.findElement(By.xpath("/html/body/app-root/app-user-account/body/table/tbody/tr[1]/td[6]/button")).click();
	  System.out.println("Enabled Login Feature");
	  Thread.sleep(2000);
	  //Disable Button
	  //driver.findElement(By.xpath("/html/body/app-root/app-user-account/table/tbody/tr[1]/td[7]/button")).click();
	  //System.out.println("Disabled Login Feature"); 
	  }
  @Test(priority=2) public void useraccount_features() throws InterruptedException{
	  //Click on the dropdown
	  driver.findElement(By.xpath("//*[@id=\"navbarsExample02\"]/ul/li[1]/a")).click();
	  Thread.sleep(2500);
	  //Select the first option
	  driver.findElement(By.xpath("/html/body/app-root/app-user-account/body/table/tbody/tr[1]/td[9]/select")).click(); 
	  //Set button
	  driver.findElement(By.xpath("/html/body/app-root/app-user-account/body/table/tbody/tr[1]/td[9]/button")).click();
	  System.out.println("User Roles Changed");
	  Thread.sleep(2000);
	  }
  @Test(priority=3) public void authorization() throws InterruptedException {
	  //Authorization link
	  driver.findElement(By.xpath("//*[@id=\"navbarsExample02\"]/ul/li[3]/a")).click(); 
	  Thread.sleep(2500);
	  //Create Account Button
	  //driver.findElement(By.xpath("/html/body/app-root/app-authorize-registration/body/table/tbody/tr[1]/td[9]/button")).click();
	  //Thread.sleep(2500);
	  System.out.println("Authorized");
	  //Cancel Button
	  //driver.findElement(By.xpath("/html/body/app-root/app-authorize-registration/table/tbody/tr[2]/td[10]/button")).click(); 
	  //Thread.sleep(2000);
	  //System.out.println(" Not Authorized");
	  
	  }
  @Test(priority=4) public void checkbookRequests() throws InterruptedException {
	  //Checkbook Request Hyperlink
	  driver.findElement(By.xpath("//*[@id=\"navbarsExample02\"]/ul/li[2]/a")).click(); 
	  Thread.sleep(2000);
	  //Confirm Request Button
	 // driver.findElement(By.xpath("/html/body/app-root/app-checkbook-requests/body/table/tbody/tr/td[6]/button")).click(); 
	  //Thread.sleep(2000);
	  System.out.println("Request Confirmed");
	  
	  }
  @Test(priority=5) public void logout() throws InterruptedException {
		//LogOut Button
	  driver.findElement(By.xpath("//*[@id=\"navbarsExample02\"]/ul/li[5]/a")).
	  click(); 
	  Thread.sleep(2000);
	  System.out.println("Logged Out");
	  
	  }
  @Test(priority=6) public void login_Fail() throws InterruptedException { 
		 driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		 driver.findElement(By.name("inputUserName")).sendKeys("admin");
		  driver.findElement(By.name("password")).sendKeys("admin");
		  Thread.sleep(2500);
		  //Login Button
		  driver.findElement(By.xpath("/html/body/app-root/app-login/body/div/form/button")).click();
		  Alert alert = driver.switchTo().alert();
		  Thread.sleep(2000);
		  alert.accept();
		  String actualUrl="http://localhost:4200/user-account";
		  String expectedUrl= driver.getCurrentUrl();
		  if(!actualUrl.equalsIgnoreCase(expectedUrl)) {
		  System.out.println("Login UnSuccessful"); }
		  driver.manage().window().maximize();
}
	 
  
}
