package com.example;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class Usertest {
	public String baseUrl="http://localhost:4200";
	String driverPath="D:\\95\\chromedriver.exe";
	public WebDriver driver;
  @BeforeTest
  public void launchBrowser() {
	  System.out.println("Chrome Browser"); 
      System.setProperty("webdriver.chrome.driver", driverPath);
      driver = new ChromeDriver();
      driver.get(baseUrl);
      driver.manage().window().maximize();
      driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	  
  }
  
  @Test
  public void LoginTest() throws InterruptedException {
		 // System.setProperty("webdriver.chrome.driver", driverPath);
		  //WebDriver driver = new ChromeDriver();
	      driver.get("http://localhost:4200/login");
	      Thread.sleep(2000);
		  driver.findElement(By.xpath("/html/body/app-root/app-login/body/div/form/div[1]/input")).sendKeys("Barath");
		  driver.findElement(By.xpath("/html/body/app-root/app-login/body/div/form/div[2]/input")).sendKeys("barath29");
		  driver.findElement(By.xpath("/html/body/app-root/app-login/body/div/form/div[3]/button")).click();
		  WebDriverWait wait=new WebDriverWait(driver, 14);
		  System.out.println("Login Successfull");
		  Thread.sleep(2500);
	  }
  @Test
  public void Transactionhistorytest() throws InterruptedException
  {
	  driver.findElement(By.xpath("//*[@id=\"navbarsExample04\"]/ul/li[1]/a")).click();
	  Thread.sleep(2000);
	  System.out.println("Transaction History Displayed");
	  
  }
  @Test
  public void Transferhistorytest() throws InterruptedException {
	  driver.findElement(By.xpath("//*[@id=\"navbarsExample04\"]/ul/li[2]/a")).click();
	  Thread.sleep(2000);
	  System.out.println("Transfer History Displayed");
	  
  }
  @Test
  public void Transfermoneytest() throws InterruptedException {
	  driver.findElement(By.xpath("//*[@id=\"navbarsExample04\"]/ul/li[3]/a")).click();
	  Thread.sleep(2000);
	  driver.findElement(By.xpath("/html/body/app-root/app-transfer-between-accounts/body/div/form/div[3]/input")).sendKeys("ICIN7465");
	  driver.findElement(By.xpath("/html/body/app-root/app-transfer-between-accounts/body/div/form/div[4]/input")).sendKeys("391491820215");
	  driver.findElement(By.xpath("/html/body/app-root/app-transfer-between-accounts/body/div/form/div[5]/input")).sendKeys("100");
	  Thread.sleep(2000);
	  driver.findElement(By.xpath("/html/body/app-root/app-transfer-between-accounts/body/div/form/div[6]/button")).click();
	 
	  driver.findElement(By.xpath("/html/body/div/div/div[3]/button[1]")).click();
	  System.out.println("Transfer Money Successfull");
	  Thread.sleep(2000);
	  

	  
  }
  @Test
  public void Usersectiontest() throws InterruptedException {
	  driver.findElement(By.xpath("//*[@id=\"dropdown04\"]")).click();
	  driver.findElement(By.xpath("//*[@id=\"navbarsExample04\"]/ul/li[5]/div/a[1]")).click();
	  driver.findElement(By.xpath("/html/body/app-root/app-edit-profile/body/div[1]/form/div/div[1]/input")).sendKeys("9877700678");
	    driver.findElement(By.xpath("/html/body/app-root/app-edit-profile/body/div[1]/form/div/div[2]/input")).sendKeys("Mumbai");
	    driver.findElement(By.xpath("/html/body/app-root/app-edit-profile/body/div[1]/form/div/div[2]/div[1]/input")).sendKeys("barath2@gmail.com");
	    driver.findElement(By.xpath("/html/body/app-root/app-edit-profile/body/div[1]/form/div/div[2]/div[2]/input")).sendKeys("barath29");
	    driver.findElement(By.xpath("/html/body/app-root/app-edit-profile/body/div[1]/form/div/div[2]/div[3]/input")).sendKeys("barath29");
	    Thread.sleep(2000);
	    //driver.findElement(By.xpath("/html/body/app-root/app-edit-profile/div[1]/form/div/div[3]/button")).click();
	    System.out.println("Profile edited");
	    driver.manage().timeouts().implicitlyWait(14, TimeUnit.SECONDS);   
	    driver.findElement(By.xpath("//*[@id=\"dropdown04\"]")).click();
	    driver.findElement(By.xpath("//*[@id=\"navbarsExample04\"]/ul/li[5]/div/a[2]")).click();
	    Thread.sleep(2000);
	    //wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html/body/app-root/app-login/div/form/h3")));
	    System.out.println("Signed Out");
  }
  
}
