package com.example;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class Actiontest {
	public String baseUrl="http://localhost:4200";
	String driverPath="D:\\95\\chromedriver.exe";
	public WebDriver driver;
	@BeforeTest
	  public void launchBrowser() {
		  System.out.println("Chrome Browser"); 
	      System.setProperty("webdriver.chrome.driver", driverPath);
	      driver = new ChromeDriver();
	      driver.get(baseUrl);
	      driver.manage().window().maximize();
	      driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		  
	  }
  @Test
  public void Checkbooktest() throws InterruptedException {
	  driver.get("http://localhost:4200/login");
      Thread.sleep(2000);
	  driver.findElement(By.xpath("/html/body/app-root/app-login/body/div/form/div[1]/input")).sendKeys("Prashanth");
	  driver.findElement(By.xpath("/html/body/app-root/app-login/body/div/form/div[2]/input")).sendKeys("prashanth123");
	  driver.findElement(By.xpath("/html/body/app-root/app-login/body/div/form/div[3]/button")).click();
	  WebDriverWait wait=new WebDriverWait(driver, 14);
	  System.out.println("Login Successfull");
	  Thread.sleep(2500);
	  driver.findElement(By.xpath("//*[@id=\"navbarsExample04\"]/ul/li[4]/a")).click();
	  driver.findElement(By.xpath("/html/body/app-root/app-cheque-book-request/body/div/div[2]/select")).click();
	  driver.findElement(By.xpath("/html/body/app-root/app-cheque-book-request/body/div/div[2]/select")).click();
	  //driver.findElement(By.xpath("/html/body/app-root/app-cheque-book-request/body/div/div[2]/button")).click();
	  Thread.sleep(2000);
	  System.out.println("Checkbook request sucessful");
  }
}
